export type DeviceType = 'mobile' | 'tablet' | 'desktop';
