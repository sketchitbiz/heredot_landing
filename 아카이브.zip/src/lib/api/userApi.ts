
// adminApi.ts를 참조해서 유저 도메인 API를 작성합니다.
// please refer to adminApi.ts to write user domain API.