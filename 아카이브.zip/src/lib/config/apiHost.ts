// src/lib/config/apiHost.ts
export const API_HOST = process.env.NEXT_PUBLIC_API_HOST!;
export const ENV_NAME = process.env.NEXT_PUBLIC_ENV_NAME;
