import { GeneratingTokens } from "@mui/icons-material";
import React from "react";
import GenericListGuide from "../../components/CustomList/GenericListGuide";

const page = () => {
  return (
    <>
      <GenericListGuide />
    </>
  );
};

export default page;
