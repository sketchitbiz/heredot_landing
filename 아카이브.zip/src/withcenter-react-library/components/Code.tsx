export default function Code({ code }: { code: string }) {
  return <p className="mt-5">{code}</p>;
}
