(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_f0e4c1a2._.js",
  "chunks": [
    "static/chunks/[root of the server]__140ccadf._.css",
    "static/chunks/node_modules_b6a7b596._.js",
    "static/chunks/src_101b2d5c._.js"
  ],
  "source": "dynamic"
});
