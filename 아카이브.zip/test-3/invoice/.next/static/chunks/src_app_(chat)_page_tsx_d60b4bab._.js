(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_(chat)_page_tsx_d60b4bab._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_(chat)_page_tsx_d60b4bab._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_8325123c._.js",
    "static/chunks/src_2ed33d97._.js",
    "static/chunks/node_modules_next_8f80055c._.js",
    "static/chunks/node_modules_@firebase_storage_dist_index_esm2017_b3a08d2a.js",
    "static/chunks/node_modules_d73aec5c._.js",
    "static/chunks/node_modules_micromark-core-commonmark_dev_lib_36a4b45d._.js",
    "static/chunks/node_modules_parse5_dist_afbcc6e3._.js",
    "static/chunks/node_modules_@fortawesome_pro-light-svg-icons_index_mjs_4109cc30._.js",
    "static/chunks/node_modules_@firebase_firestore_dist_index_esm2017_c2fcaa2e.js",
    "static/chunks/node_modules_@firebase_c0ff75a9._.js",
    "static/chunks/node_modules_@fortawesome_84296602._.js",
    "static/chunks/node_modules_6027f12c._.js",
    "static/chunks/src_app_(chat)_page_module_30a5b68f.css"
  ],
  "source": "dynamic"
});
