(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_2ed33d97._.js", {

"[project]/src/app/(chat)/page.module.css [app-client] (css module)": ((__turbopack_context__) => {

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.v({
  "chatMessages": "page-module__0nLysq__chatMessages",
});
}}),
"[project]/src/components/Spinner.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Spinner)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Spinner() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "status",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                "aria-hidden": "true",
                className: "w-8 h-8 text-gray-200 animate-spin dark:text-gray-600 fill-blue-600",
                viewBox: "0 0 100 101",
                fill: "none",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z",
                        fill: "currentColor"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Spinner.tsx",
                        lineNumber: 5,
                        columnNumber: 17
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        d: "M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z",
                        fill: "currentFill"
                    }, void 0, false, {
                        fileName: "[project]/src/components/Spinner.tsx",
                        lineNumber: 6,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/Spinner.tsx",
                lineNumber: 4,
                columnNumber: 13
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "sr-only",
                children: "Loading..."
            }, void 0, false, {
                fileName: "[project]/src/components/Spinner.tsx",
                lineNumber: 8,
                columnNumber: 13
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/Spinner.tsx",
        lineNumber: 3,
        columnNumber: 9
    }, this);
}
_c = Spinner;
var _c;
__turbopack_context__.k.register(_c, "Spinner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/chat.reducer.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "addAnalyzeChunk": (()=>addAnalyzeChunk),
    "addChatHistory": (()=>addChatHistory),
    "addFile": (()=>addFile),
    "addHistories": (()=>addHistories),
    "addInvoiceChunk": (()=>addInvoiceChunk),
    "analysisLoadingOff": (()=>analysisLoadingOff),
    "analysisLoadingOn": (()=>analysisLoadingOn),
    "chatInitialState": (()=>chatInitialState),
    "chatReducer": (()=>chatReducer),
    "hideAnalysis": (()=>hideAnalysis),
    "loadingOff": (()=>loadingOff),
    "loadingOn": (()=>loadingOn),
    "removeFile": (()=>removeFile),
    "reset": (()=>reset),
    "resetAnalyzeChunk": (()=>resetAnalyzeChunk),
    "resetFiles": (()=>resetFiles),
    "resetInvoiceChunk": (()=>resetInvoiceChunk),
    "resetPrompt": (()=>resetPrompt),
    "setDragging": (()=>setDragging),
    "setInputBoxVisibility": (()=>setInputBoxVisibility),
    "setProgress": (()=>setProgress),
    "setPrompt": (()=>setPrompt),
    "showAnalysis": (()=>showAnalysis)
});
const chatInitialState = {
    history: [
        {
            role: "platform-selection",
            text: ""
        },
        {
            role: "model",
            text: "Please select the category you want to create. You can select multiple items"
        },
        {
            role: "model",
            text: "Hello! This is HereDot, a company specializing in IT prototype manufacturing."
        }
    ],
    invoiceChunck: "",
    analyzeChunck: "",
    prompt: "",
    files: [],
    progress: 0,
    loading: false,
    analysisLoading: false,
    dragging: false,
    isInputBoxVisible: false
};
function chatReducer(state, action) {
    switch(action.type){
        case "addInvoiceChunk":
            {
                return {
                    ...state,
                    invoiceChunck: state.invoiceChunck + action.chunk
                };
            }
        case "resetInvoiceChunk":
            return {
                ...state,
                invoiceChunck: ""
            };
        case "addAnalyzeChunk":
            {
                return {
                    ...state,
                    analyzeChunck: state.analyzeChunck + action.chunk
                };
            }
        case "resetAnalyzeChunk":
            return {
                ...state,
                analyzeChunck: ""
            };
        case "showAnalysis":
            {
                const newHistory = [
                    ...state.history
                ];
                newHistory[action.index].hide = true;
                return {
                    ...state,
                    history: newHistory
                };
            }
        case "hideAnalysis":
            {
                const newHistory = [
                    ...state.history
                ];
                newHistory[action.index].hide = false;
                return {
                    ...state,
                    history: newHistory
                };
            }
        case "loadingOn":
            return {
                ...state,
                loading: true
            };
        case "loadingOff":
            return {
                ...state,
                loading: false
            };
        case "analysisLoadingOn":
            return {
                ...state,
                analysisLoading: true
            };
        case "analysisLoadingOff":
            return {
                ...state,
                analysisLoading: false
            };
        case "setPrompt":
            return {
                ...state,
                prompt: action.prompt
            };
        case "resetPrompt":
            return {
                ...state,
                prompt: ""
            };
        case "addFile":
            return {
                ...state,
                files: [
                    ...state.files,
                    action.file
                ],
                progress: 0
            };
        case "removeFile":
            return {
                ...state,
                files: state.files.filter((file)=>file.fileUri !== action.file.fileUri)
            };
        case "resetFiles":
            return {
                ...state,
                files: []
            };
        case "setProgress":
            return {
                ...state,
                progress: action.progress
            };
        case "addChatHistory":
            {
                const newHistory = {
                    ...state,
                    history: [
                        action.history,
                        ...state.history
                    ]
                };
                return newHistory;
            }
        case "addHistories":
            {
                const newHistory = {
                    ...state,
                    history: [
                        ...action.histories,
                        ...state.history
                    ]
                };
                return newHistory;
            }
        case "setDragging":
            {
                return {
                    ...state,
                    dragging: action.dragging
                };
            }
        case "setInputBoxVisibility":
            {
                return {
                    ...state,
                    isInputBoxVisible: action.isInputBoxVisible
                };
            }
        case "reset":
            return chatInitialState;
        default:
            return state;
    }
}
function addInvoiceChunk(chunk) {
    return {
        type: "addInvoiceChunk",
        chunk
    };
}
function resetInvoiceChunk() {
    return {
        type: "resetInvoiceChunk"
    };
}
function addAnalyzeChunk(chunk) {
    return {
        type: "addAnalyzeChunk",
        chunk
    };
}
function showAnalysis(index) {
    return {
        type: "showAnalysis",
        index
    };
}
function hideAnalysis(index) {
    return {
        type: "hideAnalysis",
        index
    };
}
function resetAnalyzeChunk() {
    return {
        type: "resetAnalyzeChunk"
    };
}
function loadingOn() {
    return {
        type: "loadingOn"
    };
}
function loadingOff() {
    return {
        type: "loadingOff"
    };
}
function analysisLoadingOn() {
    return {
        type: "analysisLoadingOn"
    };
}
function analysisLoadingOff() {
    return {
        type: "analysisLoadingOff"
    };
}
function setPrompt(prompt) {
    return {
        type: "setPrompt",
        prompt
    };
}
function resetPrompt() {
    return {
        type: "resetPrompt"
    };
}
function addFile(file) {
    return {
        type: "addFile",
        file
    };
}
function removeFile(file) {
    return {
        type: "removeFile",
        file
    };
}
function resetFiles() {
    return {
        type: "resetFiles"
    };
}
function setProgress(progress) {
    return {
        type: "setProgress",
        progress
    };
}
function addChatHistory(history) {
    return {
        type: "addChatHistory",
        history
    };
}
function addHistories(histories) {
    return {
        type: "addHistories",
        histories: histories.reverse()
    };
}
function reset() {
    return {
        type: "reset"
    };
}
function setDragging(dragging) {
    return {
        type: "setDragging",
        dragging
    };
}
function setInputBoxVisibility(isInputBoxVisible) {
    return {
        type: "setInputBoxVisibility",
        isInputBoxVisible
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/firebase/firebase.functions.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "deleteImage": (()=>deleteImage),
    "getMimeType": (()=>getMimeType),
    "uploadFile": (()=>uploadFile),
    "uploadFiles": (()=>uploadFiles),
    "uploadImage": (()=>uploadImage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$storage$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/storage/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/storage/dist/index.esm2017.js [app-client] (ecmascript)");
;
function uploadImage(event, { onUpload, progress, deleteUrl }) {
    const files = event.target.files;
    if (!files || files.length == 0) return;
    uploadFile(files[0], {
        onUpload: (data)=>{
            event.target.value = ""; // Clear the input value to allow re-uploading the same file;
            onUpload(data);
        },
        progress,
        deleteUrl
    });
}
async function uploadFile(file, { onUpload, progress, deleteUrl }) {
    const uploadRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ref"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorage"])(), `tmp/${file.name}`);
    const uploadTask = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadBytesResumable"])(uploadRef, file);
    uploadTask.on("state_changed", (snapshot)=>{
        const percent = snapshot.bytesTransferred / snapshot.totalBytes * 100;
        // console.log(`Upload is ${percent}% done`);
        if (progress) progress(percent);
        switch(snapshot.state){
            case "paused":
                console.log("Upload is paused");
                break;
            case "running":
                console.log("Upload is running");
                break;
        }
    }, (error)=>{
        console.error(error);
    }, ()=>{
        console.log("Upload complete");
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDownloadURL"])(uploadTask.snapshot.ref).then((downloadURL)=>{
            console.log("File available at", downloadURL);
            if (deleteUrl) {
                console.log("Delete  url", deleteUrl);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteObject"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ref"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorage"])(), deleteUrl)).then(()=>{
                    console.log("File deleted successfully");
                }).catch((error)=>{
                    console.log("Uh-oh, an error occurred!", error);
                });
            }
            onUpload({
                name: file.name,
                fileUri: downloadURL,
                mimeType: file.type
            });
        });
    });
}
function deleteImage(url, { onSuccess, onError } = {}) {
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["deleteObject"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ref"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorage"])(), url)).then(()=>{
        console.log("File deleted successfully");
        if (onSuccess) onSuccess(url);
    }).catch((error)=>{
        console.log("Uh-oh, an error occurred!", error);
        if (onError) onError(url);
    });
}
async function getMimeType(fileUrl) {
    try {
        // Create a reference to the file
        const fileRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ref"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getStorage"])(), fileUrl);
        // Get the metadata of the file
        const metadata = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$storage$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getMetadata"])(fileRef);
        // Return the contentType (MIME type)
        return metadata.contentType || null;
    } catch (error) {
        console.error("Error fetching metadata:", error);
        return null;
    }
}
function uploadFiles(files, options) {
    if (!files) return;
    files.forEach((file)=>{
        console.log(file.name);
        if (file && (file.type.startsWith("image/") || file.type.endsWith("/pdf"))) {
            uploadFile(file, options);
        }
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/UploadImageButton.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UploadImageButton)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$firebase$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/firebase/firebase.functions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
function UploadImageButton(options) {
    _s();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "UploadImageButton.useEffect": ()=>{
            document.onpaste = ({
                "UploadImageButton.useEffect": (e)=>{
                    if (e.clipboardData) {
                        const items = Array.from(e.clipboardData.items).filter({
                            "UploadImageButton.useEffect.items": (item)=>item.kind === "file"
                        }["UploadImageButton.useEffect.items"]).map({
                            "UploadImageButton.useEffect.items": (item)=>item.getAsFile()
                        }["UploadImageButton.useEffect.items"]).filter({
                            "UploadImageButton.useEffect.items": (file)=>file !== null
                        }["UploadImageButton.useEffect.items"]); // Filter out null values
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$firebase$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadFiles"])(items, options);
                    }
                // console.log("items", items, items?.length);
                // for (let i = 0; i < items.length; i++) {
                //   const item = items[i];
                //   if (item.kind === "file") {
                //     const file = item.getAsFile();
                //     if (
                //       file &&
                //       (file.type.startsWith("image/") || file.type.endsWith("/pdf"))
                //     ) {
                //       // console.log("file", file);
                //       uploadFile(file, options);
                //     }
                //   }
                }
            })["UploadImageButton.useEffect"];
            return ({
                "UploadImageButton.useEffect": ()=>{
                    // Cleanup the paste event listener when the component unmounts
                    // console.log("cleanup paste event listener");
                    document.onpaste = null;
                }
            })["UploadImageButton.useEffect"];
        }
    }["UploadImageButton.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative flex items-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                className: "absolute bottom-0 left-0 right-0 top-0 text-8xl opacity-0 cursor-pointer",
                type: "file",
                accept: "image/png, image/jpeg, image/jpg, application/pdf",
                onChange: (e)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$firebase$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadImage"])(e, options)
            }, void 0, false, {
                fileName: "[project]/src/components/UploadImageButton.tsx",
                lineNumber: 44,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                fill: "none",
                viewBox: "0 0 24 24",
                strokeWidth: 1.5,
                stroke: "currentColor",
                className: "size-8 mx-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z"
                    }, void 0, false, {
                        fileName: "[project]/src/components/UploadImageButton.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        d: "M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z"
                    }, void 0, false, {
                        fileName: "[project]/src/components/UploadImageButton.tsx",
                        lineNumber: 63,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/UploadImageButton.tsx",
                lineNumber: 50,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/UploadImageButton.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_s(UploadImageButton, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = UploadImageButton;
var _c;
__turbopack_context__.k.register(_c, "UploadImageButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/config/schema.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "FEATURE_SCHEMA": (()=>FEATURE_SCHEMA),
    "FILE_EXTRACTION_SCHEMA": (()=>FILE_EXTRACTION_SCHEMA),
    "FILE_FEATURE_SCHEMA": (()=>FILE_FEATURE_SCHEMA),
    "GROUP_FEATURE_SCHEMA": (()=>GROUP_FEATURE_SCHEMA),
    "GROUP_FILE_FEATURE_SCHEMA": (()=>GROUP_FILE_FEATURE_SCHEMA),
    "INVOICE_SCHEMA": (()=>INVOICE_SCHEMA)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/vertexai/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/vertexai/dist/esm/index.esm2017.js [app-client] (ecmascript)");
;
const FEATURE_SCHEMA = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].object({
    properties: {
        feature: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The name of the feature must be identical to the one in the <DATA>"
        }),
        description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The description of the feature"
        }),
        amount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The amount of the feature. if not set put (contact admin)"
        }),
        duration: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The duration of the feature. if not set put (contact admin)"
        }),
        category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The category of the feature"
        }),
        pages: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].number({
            description: "The number of pages for the feature. if not set put (contact admin)"
        })
    }
});
const GROUP_FEATURE_SCHEMA = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].object({
    description: "List of categories or category features included in the project",
    properties: {
        category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "Category or Common category of features included in the project"
        }),
        items: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].array({
            description: "List of one or more features that belong to the common category",
            items: FEATURE_SCHEMA
        })
    }
});
const INVOICE_SCHEMA = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].object({
    properties: {
        project: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The name of the project"
        }),
        invoiceGroup: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].array({
            description: "List of features included in the project",
            items: GROUP_FEATURE_SCHEMA
        }),
        total: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].object({
            properties: {
                amount: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].number({
                    description: "The total amount of the project"
                }),
                duration: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].number({
                    description: "The total duration of the project"
                }),
                pages: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].number({
                    description: "The total pages of the project"
                })
            }
        })
    }
});
const FILE_FEATURE_SCHEMA = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].object({
    properties: {
        feature: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The name of the feature"
        }),
        description: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The description of the feature"
        }),
        category: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].string({
            description: "The category of the feature"
        })
    }
});
const GROUP_FILE_FEATURE_SCHEMA = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].array({
    description: "List of one or more features that belong to the common category",
    items: FILE_FEATURE_SCHEMA
});
const FILE_EXTRACTION_SCHEMA = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].object({
    properties: {
        features: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].array({
            description: "List of identified features extracted from the file",
            items: GROUP_FILE_FEATURE_SCHEMA
        }),
        missing_features: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Schema"].array({
            description: "List of suggested additional features that could enhance the web application",
            items: GROUP_FILE_FEATURE_SCHEMA
        })
    }
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/config/instruction.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
// import { NEW_DATA } from "./data";
__turbopack_context__.s({
    "EXTRACTION_OUPUT_JSON": (()=>EXTRACTION_OUPUT_JSON),
    "EXTRACTION_OUPUT_MARKDOWN": (()=>EXTRACTION_OUPUT_MARKDOWN),
    "IMAGE_AND_PDF_EXTRACTION_INSTRUCTION": (()=>IMAGE_AND_PDF_EXTRACTION_INSTRUCTION),
    "IMAGE_EXTRACTION_INSTRUCTION": (()=>IMAGE_EXTRACTION_INSTRUCTION),
    "PDF_EXTRACTION_INSTRUCTION": (()=>PDF_EXTRACTION_INSTRUCTION),
    "PERSONA_EXTRACTION_INSTRUCTION": (()=>PERSONA_EXTRACTION_INSTRUCTION),
    "PERSONA_INSTRUCTION": (()=>PERSONA_INSTRUCTION),
    "SYSTEM_INSTRUCTION": (()=>SYSTEM_INSTRUCTION)
});
const PERSONA_INSTRUCTION = `
Make your response faster and more accurate by following these instructions.
You are an AI IT Consultant specialized in generating professional invoices for web and app development projects. You should base your answer from the given DATA. Your task is to create a detailed invoice that includes the project name, category, features, description, amount, and duration. Always present the invoice in a Markdown table format and continuously improve it based on user feedback.

Expected User Input
Examples: "I want to build a social media app", "I want to build a chat app", "I want to build a shopping mall", "I want to build a game app".
Users may also provide a list of features they want to include in the project.
Your Responsibilities
Identify Project Type: Determine the project type based on user input.
Suggest Essential Features: Provide a list of essential features that are available in <DATA> that should be included in the project.
Gather Additional Features: Ask the user if there are more features they want to include and suggest related features that are available in <DATA>.
UI Design Preference: Inquire if the user prefers a fine UI design or a simple UI design.
Feature name must have the same name as in the <DATA> and must be identical to the one in the <DATA>.
If theres no similar feature in the <DATA> then add the feature name,description in the invoice with the amount and "Contact admin".
Generate Invoice: Create a feature summary, amount, and working days for each feature. At the bottom of the table, include the total cost and total working days.
Unsupported Features: If the user requests a feature that is not supported, inform them and guide them to contact the administrator at 010-8234-2311.
Always generate the response in a Markdown table format.
The table should only have the following columns first: Category,Feature, Description, Amount, Note, Action.
Later on if user ask to display the category of each feature in the invoice, then add a category column on the first column of the table.
Later on if user ask to display the number of pages for each feature in the invoice, then add a pages column on the end column of the table.
The table should be well-formatted and easy to read.


Example Essential Features

### Features to Include:
1. **User management** - Includes login, registration, and password recovery.
   - amount: 100,000
   - Duration: 5 days
   - pages: 30
2. **User Profile Management** - Edit profile information
   - amount: 100,000
   - Duration: 5 days
   - pages: 5
3. **News Feed** - Display posts from followed users
   - amount: 100,000
   - Duration: 5 days
    - pages: 12
4. **Messaging System** - Real-time chat functionality
   - amount: 100,000
   - Duration: 5 days
   - pages: 8
5. **Notifications** - Push notifications for likes, comments, and messages
   - amount: 100,000
   - Duration: 5 days
   - pages: 5
   
Example Related Features
   
### Additional Related Features you may want (Optional):
- **Video/audio Streaming service** - o streaming platform with user subscriptions
   - amount: 300,000
   - Duration: 3 days
   - pages: 5
- **Feed system** - Allow other's user feeds
   - amount: 150,000
   - Duration: 2 days
   - pages: 10
- **Google login** - ogin with their Google account
   - amount: 100,000
   - Duration: 5 days
   - pages: 15

Example Invoice Markdown Table

#### Project Invoice without category and pages

| Category | Feature       | Description                                      | Amount     |   Note          | Actions                 | 
|----------|---------------|--------------------------------------------------|------------|-----------------|-------------------------|
|          | User Login    | Secure user login with email and password        | 100,000    |                 | <button>Delete</button> |
|          | User Profile  | User profile management                          | 800,000    |                 | <button>Delete</button> |
|          | Chat System   | Real-time chat functionality                     | 200,000    |                 | <button>Delete</button> |
|          | UI Design     | Fine UI design                                   | 100,500    |                 | <button>Delete</button> |
|          | Design Files  | All original design files in a zip file          | 500,000    |                 | <button>Delete</button> |
|          | ...           | ...                                              | ...        | ...             | <button>Delete</button> |
| Total                                                                       | 1,700,500  |                 | <button>Delete</button> |

This data should be on the top of the invoice table.

화면설계	스토리보드	IT프로젝트를 진행하기 위한 전반적인 설계를 정의 합니다	"1. Mobile 경우 : 본수 기준 1장당 10만원
2. PC 경우 : 본수 기준 1장당 15만원"
화면디자인	UI/UX디자인	스토리 보드 기반 UI/UX 디자인을 정의합니다	"1. Mobile 경우 : 본수 기준 1장당 10만원
2. PC 경우 : 본수 기준 1장당 15만원"
화면퍼블리싱	퍼블리싱	디자인기반 화면 UI/UX 코드를 개발합니다	"1. Mobile 경우 : 본수 기준 1장당 10만원
2. PC 경우 : 본수 기준 1장당 15만원"
서버 셋업	환경구축	고객사 서버내 도커 기반 Back / Front 개발 환경을 조성합니다	

(can you also translate it if the user prompt is english?)

The note column is optional. If you see a base pricing in the feature description, then add a note column and add the base pricing in the note column. If there is no base pricing, then leave the note column empty.


`;
const SYSTEM_INSTRUCTION = `

${PERSONA_INSTRUCTION}
      
<INSTRUCTIONS>
To complete the task, you need to follow these steps:
1. The user will provide what project he wants to build
2. Provide a list of features that the user must include in the project.
3. Ask the user if theres more feature he wants to include in the project. and list related features.
4. Provide the total amount of the project.
5. ALWAYS include the invoice and must be in a table format at the end.
6. Add a <button>Delete</button> (also add a data attribute based on the feature) at the end of the row table

The generated text should be in markdown + html
</INSTRUCTIONS>

`;
const PERSONA_EXTRACTION_INSTRUCTION = `
You are an AI Web app assistant tasked with analyzing a PDF document or image to extract information relevant to building or enhancing a web application. Please follow these instructions carefully:
`;
const EXTRACTION_OUPUT_JSON = `
4. **Output format**:
   - Provide the extracted information in a structured JSON format as follows:
\`\`\`json
{
  "features": [
    {
      "feature_name": "Feature Name",
      "description": "Description of the feature",
      "category": "Category of the feature",
    },
    ...
  ],
  "missing_features": [
    {
      "feature_name": "Suggested Feature Name",
      "description": "Description of the suggested feature"
    },
    ...
  ]
}
\`\`\`
`;
const EXTRACTION_OUPUT_MARKDOWN = `
4. **Output format**:
   - Provide the extracted information in a structured MARKDOWN format as follows:
   
| Category | Feature       | Description                                      |
|----------|---------------|--------------------------------------------------|
| ...      | User Login    | Secure user login with email and password        |
| ...      | User Profile  | User profile management                          |
| ...      | Chat System   | Real-time chat functionality                     |
| ...      | UI Design     | Fine UI design                                   |
| ...      | Design Files  | All original design files in a zip file          |
| ...      | ...           | ...                                              |
`;
const PDF_EXTRACTION_INSTRUCTION = `
1. **Analyze the PDF file section by section**:
   - Identify the purpose of each section and summarize its content.
   - Look for any technical requirements, user needs, or design specifications mentioned in the document.

2. **Extract features**:
   - Based on the content of each section, identify features that are required or suggested for the web application.
   - For each feature, provide the following details:
     - **Feature Name**: A concise name for the feature.
     - **Description**: A brief explanation of what the feature does or its purpose.
     - **Category**: Categorize the feature (e.g., Authentication, UI/UX, Payment, Notifications, etc.).

3. **Identify missing features**:
   - If the document implies functionality or requirements that are not explicitly mentioned, suggest additional features that could enhance the web application.

${EXTRACTION_OUPUT_MARKDOWN}


5. **Additional considerations**:
   - If the document includes diagrams, tables, or images, describe their content and how they relate to the features.
   - If the document includes references to external tools, APIs, or frameworks, include them in the analysis.

Please ensure the analysis is thorough and accurate, and focus on extracting actionable insights for web application development.`;
const IMAGE_EXTRACTION_INSTRUCTION = `
1. **Analyze the image content**:
   - Identify the type of image (e.g., screenshot, diagram, UI mockup, chart, or photo).
   - If the image contains text, extract all visible text and organize it logically.
   - If the image contains UI elements, describe their purpose and functionality.

2. **Extract features**:
   - Based on the content of the image, identify features that are required or suggested for the web application.
   - For each feature, provide the following details:
     - **Feature Name**: A concise name for the feature.
     - **Description**: A brief explanation of what the feature does or its purpose.
     - **Category**: Categorize the feature (e.g., Authentication, UI/UX, Payment, Notifications, etc.).

3. **Identify missing features**:
   - If the image implies functionality or requirements that are not explicitly mentioned, suggest additional features that could enhance the web application.

${EXTRACTION_OUPUT_MARKDOWN}

5. **Additional considerations**:
   - If the image contains diagrams, describe their structure and how they relate to the features.
   - If the image includes references to external tools, APIs, or frameworks, include them in the analysis.
   - If the image contains visual elements (e.g., buttons, forms, or navigation menus), describe their layout and functionality.

6. **Focus on actionable insights**:
   - Ensure the analysis is thorough and accurate.
   - Focus on extracting actionable insights that can directly contribute to web application development.
`;
const IMAGE_AND_PDF_EXTRACTION_INSTRUCTION = `
${PERSONA_EXTRACTION_INSTRUCTION}

Specific Instructions for PDFs
${PDF_EXTRACTION_INSTRUCTION}

Specific Instructions for Images
${IMAGE_EXTRACTION_INSTRUCTION}
<>
`;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/InvoiceBubble.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>InvoiceBubble)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/react-markdown/lib/index.js [app-client] (ecmascript) <export Markdown as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rehype$2d$raw$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/rehype-raw/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/remark-gfm/lib/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function InvoiceBubble({ content, onDeleteFeature }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    const components = {
        button ({ ...props }) {
            const { "data-feature": dataFeature, children } = props;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                "data-feature": dataFeature,
                className: "button",
                onClick: ()=>onDeleteFeature(dataFeature || ""),
                children: children
            }, void 0, false, {
                fileName: "[project]/src/components/InvoiceBubble.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `flex flex-col`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: `flex text-sm text-gray-500}`,
                children: t("app-name")
            }, void 0, false, {
                fileName: "[project]/src/components/InvoiceBubble.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("data", {
                    className: `bg-green-100 w-11/12 p-4 rounded-md mb-4`,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                        remarkPlugins: [
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                        ],
                        rehypePlugins: [
                            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$rehype$2d$raw$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                        ],
                        components: components,
                        children: content.text
                    }, void 0, false, {
                        fileName: "[project]/src/components/InvoiceBubble.tsx",
                        lineNumber: 40,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/InvoiceBubble.tsx",
                    lineNumber: 39,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/InvoiceBubble.tsx",
                lineNumber: 38,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/InvoiceBubble.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
_s(InvoiceBubble, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = InvoiceBubble;
var _c;
__turbopack_context__.k.register(_c, "InvoiceBubble");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ContentFiles.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ContentFiles)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
;
;
function ContentFiles({ files }) {
    if (!files || files.length == 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: files.map((file, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                children: [
                    file.mimeType.startsWith("image/") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: file.fileUri,
                        width: 512,
                        height: 512,
                        alt: "Upload",
                        className: "w-auto h-full"
                    }, void 0, false, {
                        fileName: "[project]/src/components/ContentFiles.tsx",
                        lineNumber: 17,
                        columnNumber: 13
                    }, this),
                    file.mimeType.endsWith("/pdf") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        href: file.fileUri,
                        target: "_blank",
                        className: "flex flex-col items-center justify-center gap-1 p-1 text-center text-gray-500 w-24 h-24 border rounded-md",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                strokeWidth: 1.5,
                                stroke: "currentColor",
                                className: "size-8",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    d: "m18.375 12.739-7.693 7.693a4.5 4.5 0 0 1-6.364-6.364l10.94-10.94A3 3 0 1 1 19.5 7.372L8.552 18.32m.009-.01-.01.01m5.699-9.941-7.81 7.81a1.5 1.5 0 0 0 2.112 2.13"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/ContentFiles.tsx",
                                    lineNumber: 39,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/ContentFiles.tsx",
                                lineNumber: 31,
                                columnNumber: 15
                            }, this),
                            "PDF File"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/ContentFiles.tsx",
                        lineNumber: 26,
                        columnNumber: 13
                    }, this)
                ]
            }, i, true, {
                fileName: "[project]/src/components/ContentFiles.tsx",
                lineNumber: 15,
                columnNumber: 9
            }, this))
    }, void 0, false);
}
_c = ContentFiles;
var _c;
__turbopack_context__.k.register(_c, "ContentFiles");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/UserBubble.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UserBubble)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/react-markdown/lib/index.js [app-client] (ecmascript) <export Markdown as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/remark-gfm/lib/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ContentFiles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ContentFiles.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function UserBubble({ content }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `flex flex-col`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: `flex text-sm text-gray-500 justify-end`,
                children: t("user")
            }, void 0, false, {
                fileName: "[project]/src/components/UserBubble.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("data", {
                    className: "bg-blue-100 max-w-11/12 flex items-end flex-col gap-5 p-4 rounded-md mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                            remarkPlugins: [
                                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                            ],
                            children: content.text
                        }, void 0, false, {
                            fileName: "[project]/src/components/UserBubble.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ContentFiles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            files: content.files
                        }, void 0, false, {
                            fileName: "[project]/src/components/UserBubble.tsx",
                            lineNumber: 17,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/UserBubble.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/UserBubble.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/UserBubble.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_s(UserBubble, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = UserBubble;
var _c;
__turbopack_context__.k.register(_c, "UserBubble");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/ExtractAIBubble.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ExtractAIBubble)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/react-markdown/lib/index.js [app-client] (ecmascript) <export Markdown as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/remark-gfm/lib/index.js [app-client] (ecmascript)");
;
;
;
function ExtractAIBubble({ content, onClick }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `flex flex-col`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: "flex text-sm text-gray-500 justify-end",
                children: "Extract AI"
            }, void 0, false, {
                fileName: "[project]/src/components/ExtractAIBubble.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex justify-end",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("data", {
                    className: "bg-yellow-100 max-w-11/12 flex items-end flex-col p-4 rounded-md mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            className: "text-sm",
                            onClick: onClick,
                            children: content.hide ? "Show" : "Hide"
                        }, void 0, false, {
                            fileName: "[project]/src/components/ExtractAIBubble.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                            className: `${content.hide ? "hidden" : "flex flex-col"}`,
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                                remarkPlugins: [
                                    __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                                ],
                                children: content.text
                            }, void 0, false, {
                                fileName: "[project]/src/components/ExtractAIBubble.tsx",
                                lineNumber: 22,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/ExtractAIBubble.tsx",
                            lineNumber: 21,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/ExtractAIBubble.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/components/ExtractAIBubble.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/ExtractAIBubble.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = ExtractAIBubble;
var _c;
__turbopack_context__.k.register(_c, "ExtractAIBubble");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/components/UploadedChatFiles.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>UploadedChatFiles)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
;
;
function UploadedChatFiles({ files, onDelete }) {
    if (!files || files.length == 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "flex flex-wrap justify-end gap-3 px-5",
        children: files.map((file, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("data", {
                className: "relative flex min-w-24 min-h-24",
                title: file.name,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>onDelete(file),
                        className: "absolute top-1 right-1 !p-2 cursor-pointer !rounded-full !bg-red-500",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            xmlns: "http://www.w3.org/2000/svg",
                            fill: "none",
                            viewBox: "0 0 24 24",
                            strokeWidth: 1.5,
                            stroke: "currentColor",
                            className: "size-5 stroke-white-500",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                d: "m14.74 9-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 0 1-2.244 2.077H8.084a2.25 2.25 0 0 1-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 0 0-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 0 1 3.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 0 0-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 0 0-7.5 0"
                            }, void 0, false, {
                                fileName: "[project]/src/components/UploadedChatFiles.tsx",
                                lineNumber: 32,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/src/components/UploadedChatFiles.tsx",
                            lineNumber: 24,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/UploadedChatFiles.tsx",
                        lineNumber: 20,
                        columnNumber: 11
                    }, this),
                    file.mimeType.startsWith("image/") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: file.fileUri,
                        width: 154,
                        height: 154,
                        alt: "Upload",
                        className: "w-auto h-full rounded-md border"
                    }, void 0, false, {
                        fileName: "[project]/src/components/UploadedChatFiles.tsx",
                        lineNumber: 40,
                        columnNumber: 13
                    }, this),
                    file.mimeType.endsWith("/pdf") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "flex flex-col items-center justify-center w-24 h-24 bg-gray-200 rounded-md border gap-1 p-1 text-center",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                xmlns: "http://www.w3.org/2000/svg",
                                fill: "none",
                                viewBox: "0 0 24 24",
                                strokeWidth: 1.5,
                                stroke: "currentColor",
                                className: "size-5",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                    strokeLinecap: "round",
                                    strokeLinejoin: "round",
                                    d: "m18.375 12.739-7.693 7.693a4.5 4.5 0 0 1-6.364-6.364l10.94-10.94A3 3 0 1 1 19.5 7.372L8.552 18.32m.009-.01-.01.01m5.699-9.941-7.81 7.81a1.5 1.5 0 0 0 2.112 2.13"
                                }, void 0, false, {
                                    fileName: "[project]/src/components/UploadedChatFiles.tsx",
                                    lineNumber: 58,
                                    columnNumber: 17
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/UploadedChatFiles.tsx",
                                lineNumber: 50,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-xs",
                                children: file.name.length <= 12 ? file.name : file.name.substring(0, 12) + "..."
                            }, void 0, false, {
                                fileName: "[project]/src/components/UploadedChatFiles.tsx",
                                lineNumber: 64,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/UploadedChatFiles.tsx",
                        lineNumber: 49,
                        columnNumber: 13
                    }, this)
                ]
            }, "imageUrls" + index, true, {
                fileName: "[project]/src/components/UploadedChatFiles.tsx",
                lineNumber: 15,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/src/components/UploadedChatFiles.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = UploadedChatFiles;
var _c;
__turbopack_context__.k.register(_c, "UploadedChatFiles");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/withcenter-react-library/components/Spinner.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Spinner)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$pro$2d$light$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/pro-light-svg-icons/index.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@fortawesome/react-fontawesome/index.es.js [app-client] (ecmascript)");
;
;
;
function Spinner({ className, size }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$react$2d$fontawesome$2f$index$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["FontAwesomeIcon"], {
        icon: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$fortawesome$2f$pro$2d$light$2d$svg$2d$icons$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["faCircleNotch"],
        className: `fa-spin w-6 h-6 ${className}`,
        size: size
    }, void 0, false, {
        fileName: "[project]/src/withcenter-react-library/components/Spinner.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
} // Spinner component that displays a loading spinner icon.
_c = Spinner;
var _c;
__turbopack_context__.k.register(_c, "Spinner");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/withcenter-react-library/components/Loading.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Loading)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$withcenter$2d$react$2d$library$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/withcenter-react-library/components/Spinner.tsx [app-client] (ecmascript)");
;
;
function Loading({ loading, text }) {
    if (!loading) return null;
    text ??= "Please wait...";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mt-3 flex items-center gap-2 text-gray-500 dark:text-gray-400",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$withcenter$2d$react$2d$library$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/src/withcenter-react-library/components/Loading.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this),
            text
        ]
    }, void 0, true, {
        fileName: "[project]/src/withcenter-react-library/components/Loading.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = Loading;
var _c;
__turbopack_context__.k.register(_c, "Loading");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/withcenter-react-library/functions/common.functions.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
/**
 * Check if the file is an image based on its extension.
 *
 * @param file The file name or path to check.
 * @returns True if the file is an image, false otherwise.
 */ __turbopack_context__.s({
    "cut": (()=>cut),
    "fromFormData": (()=>fromFormData),
    "generateRandomString": (()=>generateRandomString),
    "is_image": (()=>is_image),
    "longDateTime": (()=>longDateTime),
    "numberWithCommas": (()=>numberWithCommas),
    "remove_html_tags": (()=>remove_html_tags),
    "remove_nbsps": (()=>remove_nbsps),
    "shortDateTime": (()=>shortDateTime),
    "strip_html": (()=>strip_html),
    "strip_tags": (()=>strip_tags),
    "veryLongDateTime": (()=>veryLongDateTime),
    "veryShortDateTime": (()=>veryShortDateTime)
});
function is_image(file) {
    // 파일 이름에 .jpg, .jpeg, .png, .gif, .bmp, .webp 확장자가 있는지 확인
    // 대소문자 구분 없이 확인
    // 예) test.jpg, test.JPG, test.Jpg
    const re = /\.(jpg|jpeg|png|gif|bmp|webp)/i.test(file);
    if (re) return re;
    // 만약, 파일 이름에 확장자가 없고, 모두 숫자로만 되어져 있다면, 기존 필고 첨부 파일로 인식하고, 이미지로 인식한다.
    // 예) 1234567890
    const filename = file.split("/").pop();
    if (filename && /^\d+$/.test(filename)) {
        return true;
    }
    return re;
}
function generateRandomString(length) {
    const characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
    let result = "";
    for(let i = 0; i < length; i++){
        result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result;
}
function fromFormData(e) {
    e.preventDefault();
    const data = Object.fromEntries(new FormData(e.currentTarget));
    return data;
}
function strip_tags(html) {
    return html.replace(/<[^>]*>?/gm, "");
}
function strip_html(text) {
    text = remove_html_tags(text);
    text = remove_nbsps(text);
    return text;
}
function remove_html_tags(text) {
    return strip_tags(text);
}
function remove_nbsps(text) {
    return text.replace(/&nbsp;/g, " ");
}
function cut(text, length, options) {
    const { pad, defaultValue } = Object.assign({
        pad: "...",
        defaultValue: "..."
    }, options);
    if (!text) return defaultValue;
    if (text.length > length) {
        return text.substring(0, length) + pad;
    }
    return text;
}
function shortDateTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    if (date.getDate() == now.getDate()) {
        return date.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });
    } else {
        return date.toLocaleString([], {
            year: "2-digit",
            month: "2-digit",
            day: "2-digit"
        });
    }
}
function veryShortDateTime(timestamp) {
    const date = new Date(timestamp);
    const now = new Date();
    if (date.getDate() == now.getDate()) {
        return date.toLocaleTimeString([], {
            hour: "2-digit",
            minute: "2-digit"
        });
    } else {
        return date.toLocaleString([], {
            month: "2-digit",
            day: "2-digit"
        });
    }
}
function longDateTime(timestamp) {
    return new Date(timestamp).toLocaleString([], {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit"
    });
}
function veryLongDateTime(timestamp) {
    //  console.log("--> timestamp", timestamp);
    return new Date(timestamp).toLocaleString([], {
        year: "numeric",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit"
    });
}
function numberWithCommas(x) {
    const [integerPart, decimalPart] = x.toString().split(".");
    const formattedInteger = integerPart.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    return decimalPart ? `${formattedInteger}.${decimalPart}` : formattedInteger;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/hooks/useAI.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>useAI)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$instruction$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/instruction.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/vertexai/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/vertexai/dist/esm/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
function useAI() {
    _s();
    const GEMINI_MODEL = "gemini-2.5-pro-preview-03-25";
    const model = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const chat = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({});
    const initialized = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useAI.useEffect": ()=>{
            if (!initialized.current) {
                ({
                    "useAI.useEffect": async ()=>{
                        const q = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["query"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["collection"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getFirestore"])(), "features"));
                        const querySnapshot = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDocs"])(q);
                        let featuresData = "";
                        querySnapshot.forEach({
                            "useAI.useEffect": (doc)=>{
                                console.log(doc.id, " => ", doc.data());
                                featuresData += `${JSON.stringify(doc.data())}`;
                            }
                        }["useAI.useEffect"]);
                        const updatedSystemInstruction = `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$instruction$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SYSTEM_INSTRUCTION"]}  <DATA> ${featuresData} </DATA>`;
                        console.log("updatedSystemInstruction", updatedSystemInstruction);
                        model.current = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGenerativeModel"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVertexAI"])(), {
                            model: GEMINI_MODEL,
                            systemInstruction: updatedSystemInstruction
                        });
                        chat.current = model.current.startChat();
                    }
                })["useAI.useEffect"]();
                initialized.current = true;
            }
        }
    }["useAI.useEffect"], []);
    return {
        model,
        chat
    };
}
_s(useAI, "g7ssPknSJ+bhE35zmrmjH8pwbSc=");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/_components/InvoiceChunck.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>InvoiceChunck)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__ = __turbopack_context__.i("[project]/node_modules/react-markdown/lib/index.js [app-client] (ecmascript) <export Markdown as default>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/remark-gfm/lib/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function InvoiceChunck({ invoiceChunck }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `flex flex-col`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: `flex text-sm text-gray-500 `,
                children: t("app-name")
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/InvoiceChunck.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("data", {
                    className: "bg-green-100 w-11/12 p-4 rounded-md mb-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$markdown$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$export__Markdown__as__default$3e$__["default"], {
                            remarkPlugins: [
                                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$remark$2d$gfm$2f$lib$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
                            ],
                            children: invoiceChunck
                        }, void 0, false, {
                            fileName: "[project]/src/app/(chat)/_components/InvoiceChunck.tsx",
                            lineNumber: 18,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/src/app/(chat)/_components/InvoiceChunck.tsx",
                            lineNumber: 19,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/(chat)/_components/InvoiceChunck.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/InvoiceChunck.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(chat)/_components/InvoiceChunck.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_s(InvoiceChunck, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = InvoiceChunck;
var _c;
__turbopack_context__.k.register(_c, "InvoiceChunck");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/_components/AnalysisChunck.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>AnalysisChunck)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
;
function AnalysisChunck() {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `flex flex-col items-end`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                className: `flex text-sm text-gray-500`,
                children: t("analysis-name")
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/AnalysisChunck.tsx",
                lineNumber: 9,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: "flex",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("data", {
                    className: "bg-yellow-100 w-11/12 p-4 rounded-md mb-4 flex items-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/AnalysisChunck.tsx",
                        lineNumber: 15,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/app/(chat)/_components/AnalysisChunck.tsx",
                    lineNumber: 11,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/AnalysisChunck.tsx",
                lineNumber: 10,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(chat)/_components/AnalysisChunck.tsx",
        lineNumber: 8,
        columnNumber: 5
    }, this);
}
_s(AnalysisChunck, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = AnalysisChunck;
var _c;
__turbopack_context__.k.register(_c, "AnalysisChunck");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/_components/PlatformSelection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>PlatformSelection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
function PlatformSelection({ selectedPlatforms, handlePlatformSelected, onPlatformProceed, disabled }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
        className: "flex items-center justify-around w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                children: t("platform-selection")
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4 items-center",
                children: [
                    "Web:",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: `${selectedPlatforms.web ? "bg-blue-800 text-white" : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                                onClick: ()=>handlePlatformSelected("web"),
                                disabled: disabled,
                                children: "Web"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                                lineNumber: 25,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: `${selectedPlatforms.mobile ? "bg-blue-800 text-white" : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                                onClick: ()=>handlePlatformSelected("mobile"),
                                disabled: disabled,
                                children: "Mobile"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                                lineNumber: 34,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4 items-center",
                children: [
                    "App:",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: `${selectedPlatforms.ios ? "bg-blue-800 text-white" : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                                onClick: ()=>handlePlatformSelected("ios"),
                                disabled: disabled,
                                children: "iOS"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                                lineNumber: 48,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: `${selectedPlatforms.android ? "bg-blue-800 text-white" : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                                onClick: ()=>handlePlatformSelected("android"),
                                disabled: disabled,
                                children: "Android"
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                        lineNumber: 47,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: `${selectedPlatforms.windows ? "bg-blue-800 text-white" : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                onClick: ()=>handlePlatformSelected("windows"),
                disabled: disabled,
                children: "Windows"
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                lineNumber: 68,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                className: `mt-4 px-4 py-2 bg-green-600 text-white rounded ${disabled ? "cursor-not-allowed " : ""}`,
                onClick: onPlatformProceed,
                disabled: disabled,
                children: "Proceed"
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(chat)/_components/PlatformSelection.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_s(PlatformSelection, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = PlatformSelection;
var _c;
__turbopack_context__.k.register(_c, "PlatformSelection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/_components/PageSelection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>PageSelection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
function PageSelection({ selectedPages, handlePagesSelected, disabled }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
        className: "flex flex-col items-center gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                children: t("choose-pages")
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 5 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(5),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 5
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 10 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(10),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 10
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 20 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(20),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 20
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 30 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(30),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 30
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 40 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(40),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 40
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 50 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(50),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 50
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 67,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                lineNumber: 48,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 70 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(70),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 70
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 78,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 90 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(90),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 90
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 87,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedPages === 100 ? "bg-blue-800 " : ""} ${disabled ? "cursor-not-allowed " : ""}`,
                        onClick: ()=>handlePagesSelected(100),
                        disabled: disabled,
                        children: t("less-than-pages", {
                            number: 100
                        })
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
                lineNumber: 77,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(chat)/_components/PageSelection.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_s(PageSelection, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = PageSelection;
var _c;
__turbopack_context__.k.register(_c, "PageSelection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/_components/FeatureSelection.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>FeatureSelection)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
;
function FeatureSelection({ selectedFeature, handleFeatureSelected, disabled }) {
    _s();
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("fieldset", {
        className: "flex flex-col items-center gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("legend", {
                children: t("choose-feature")
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                lineNumber: 17,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-4 flex-wrap",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Travel/Transportation" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Travel/Transportation"),
                        disabled: disabled,
                        children: t("travel-transportation")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 19,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "IoT App" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("IoT App"),
                        disabled: disabled,
                        children: t("iot-app")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Health/Medical" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Health/Medical"),
                        disabled: disabled,
                        children: t("health-medical")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 37,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Finance/Fund" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Finance/Fund"),
                        disabled: disabled,
                        children: t("finance-fund")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 46,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Food" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Food"),
                        disabled: disabled,
                        children: t("food")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 55,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Community" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Community"),
                        disabled: disabled,
                        children: t("community")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 64,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Shopping" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Shopping"),
                        disabled: disabled,
                        children: t("shopping")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 73,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Reverse Auction" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Reverse Auction"),
                        disabled: disabled,
                        children: t("reverse-auction")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 82,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Use Trade" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Use Trade"),
                        disabled: disabled,
                        children: t("use-trade")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 91,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "O2O" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("O2O"),
                        disabled: disabled,
                        children: t("o2o")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 100,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: `${selectedFeature === "Pay Platform" ? "bg-blue-800" : ""} ${disabled ? "cursor-not-allowed" : ""}`,
                        onClick: ()=>handleFeatureSelected("Pay Platform"),
                        disabled: disabled,
                        children: t("pay-platform")
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(chat)/_components/FeatureSelection.tsx",
        lineNumber: 16,
        columnNumber: 5
    }, this);
}
_s(FeatureSelection, "h6+q2O3NJKPY5uL0BIJGLIanww8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = FeatureSelection;
var _c;
__turbopack_context__.k.register(_c, "FeatureSelection");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/(chat)/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ChatPage)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/vertexai/dist/esm/index.esm.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/vertexai/dist/esm/index.esm2017.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/page.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/Spinner.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-redux/dist/react-redux.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$invoice$2e$slice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/store/invoice.slice.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/chat.reducer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UploadImageButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/UploadImageButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$firebase$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/firebase/firebase.functions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/schema.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$instruction$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/config/instruction.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$InvoiceBubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/InvoiceBubble.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UserBubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/UserBubble.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ExtractAIBubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/ExtractAIBubble.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UploadedChatFiles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/UploadedChatFiles.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next-intl/dist/esm/development/react-client/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$withcenter$2d$react$2d$library$2f$components$2f$Loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/withcenter-react-library/components/Loading.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$withcenter$2d$react$2d$library$2f$functions$2f$common$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/withcenter-react-library/functions/common.functions.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$hooks$2f$useAI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/hooks/useAI.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$InvoiceChunck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/_components/InvoiceChunck.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$AnalysisChunck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/_components/AnalysisChunck.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$PlatformSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/_components/PlatformSelection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$PageSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/_components/PageSelection.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$FeatureSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/app/(chat)/_components/FeatureSelection.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ChatPage() {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const storeDispatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDispatch"])();
    const [state, dispatch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReducer"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chatReducer"], __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["chatInitialState"]);
    const [promptLoading, setPromptLoading] = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].useState(false);
    const newGeminiModel = "gemini-2.5-pro-preview-03-25";
    const { model, chat } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$hooks$2f$useAI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const audioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Add useRef for audio
    const streamAudioRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null); // Add useRef for audio
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ChatPage.useEffect": ()=>{
            audioRef.current = new Audio("/ai-generating.mp3");
            audioRef.current.loop = true;
            streamAudioRef.current = new Audio("/ai-typing.mp3");
            streamAudioRef.current.loop = true;
            return ({
                "ChatPage.useEffect": ()=>{
                    audioRef.current?.pause();
                    streamAudioRef.current?.pause();
                }
            })["ChatPage.useEffect"];
        }
    }["ChatPage.useEffect"], []);
    const multiStepSelection = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])({
        platformSelected: false,
        pageSelected: false,
        featureSelected: false
    });
    // TODO: need to add interface
    const [selectedPlatforms, setSelectedPlatform] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        web: false,
        mobile: false,
        ios: false,
        android: false,
        windows: false
    });
    const [selectedPages, setSelectedPages] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedFeature, setSelectedFeature] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const t = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"])();
    async function submitPrompt(param) {
        let prompt;
        if (typeof param === "string") {
            prompt = param;
        } else {
            const { message } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$withcenter$2d$react$2d$library$2f$functions$2f$common$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["fromFormData"])(param);
            // const e = param as React.FormEvent<HTMLFormElement>;
            // const formData = new FormData(e.currentTarget);
            // const message = formData.get("message") as string;
            prompt = message;
        }
        if (!prompt && state.files.length == 0) return;
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resetPrompt"])());
        setPromptLoading(true);
        audioRef.current?.play(); // Play audio
        if (state.files.length > 0) {
            // console.log("submitFilePrompt", message);
            await submitFilePrompt(prompt);
        } else {
            // console.log("submitFilePrompt", message);
            await submitTextPrompt(prompt);
        }
    }
    async function onSubmit(e) {
        e.preventDefault();
        submitPrompt(e);
    }
    async function submitFilePrompt(message) {
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["analysisLoadingOn"])());
        const userPrompt = {
            role: "user",
            text: message
        };
        const parts = [
            `
      ${message}

      <RECAP>
      Extract the features from the image and pdf files.
      Analyze the image and pdf files section by section.
      Identify the purpose of each section and summarize its content.
      Look for any technical requirements, user needs, or design specifications mentioned in the document.
      If the image is like widget or UI, categorize the image and pdf files to what kind of widget or UI it is.
      If the image is a screenshot, identify the purpose of each section and summarize its content.
      If the image is a screenshot of another website, identify what are the features of the website.
      If the image is a screenshot of a UI, identify the purpose of each section and summarize its content.
      Provide a meaningful feature name and description for each feature.
      <RECAP/>
      `
        ];
        for (const file of state.files){
            parts.push({
                fileData: {
                    mimeType: file.mimeType,
                    fileUri: file.fileUri
                }
            });
        }
        userPrompt.files = state.files;
        userPrompt.parts = parts;
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addChatHistory"])(userPrompt));
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resetFiles"])());
        const fileModel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGenerativeModel"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVertexAI"])(), {
            model: newGeminiModel,
            systemInstruction: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$instruction$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IMAGE_AND_PDF_EXTRACTION_INSTRUCTION"]
        });
        const result = await fileModel.generateContent(parts);
        const resultText = result.response.text();
        // console.log("res::", resultText);
        const filePrompt = {
            role: "file",
            text: resultText,
            hide: true
        };
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addChatHistory"])(filePrompt));
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["analysisLoadingOff"])());
        // const result = await fileModel.generateContentStream(parts);
        // let fileModelRes = "";
        // for await (const chunk of result.stream) {
        //   const chunkText = chunk.text();
        //   fileModelRes += chunkText;
        //   // console.log(chunkText);
        //   dispatch(addAnalyzeChunk(chunkText));
        // }
        // const filePrompt: ChatHistory = {
        //   role: "file",
        //   text: fileModelRes,
        //   hide: true,
        // };
        // dispatch(addChatHistory(filePrompt));
        // dispatch(resetAnalyzeChunk());
        // dispatch(analysisLoadingOff());
        await send(`
      ${resultText}

      <RECAP>
      Base from the information above, add related features to the invoice.
      If the features are already in the invoice, please ignore them.
      If the features are not in the invoice, please add them to the invoice.
      If the features has no related features, please add them to the invoice, but put (contact admin) in the price and duration.

      Base from the missing features look for the features that are not in the invoice and add them to the invoice.


      Please always include the invoice in table format at the end. Also Suggested additional features for the app that are not in the invoice yet. Please use markdown format for the invoice. but dont add code block e.g. <pre>, <code> \'\'\'markdown"
      Also make sure that the price is in KRW
      </RECAP>
      `);
    }
    async function submitTextPrompt(message) {
        const userPrompt = {
            role: "user",
            text: message
        };
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addChatHistory"])(userPrompt));
        const request = `
      ${message}
      <RECAP>
      You should base your answer from the given <DATA>.
      Dont add any random price, duration and pages to features that are not available in the <DATA>. Instead if <DATA> has no information about the features, add the features to invoice and put (contact admin) in the price,duration and pages.
      
      Please always include the invoice in table format at the end. Also Suggested additional features for the app that are not in the invoice yet. Please use markdown format for the invoice. but dont add code block \'\'\'markdown"
      </RECAP>
      `;
        await send(request);
    }
    async function onDeleteFeature(feature) {
        const userPrompt = {
            role: "user",
            text: "Deleting the feature . . ."
        };
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addChatHistory"])(userPrompt));
        console.log("onDeleteFeature", feature);
        const request = `
      Delete the feature: ${feature} from the invoice.

      <RECAP>
      You should base your answer from the given <DATA>.
      Please always include the invoice in table format at the end. Also Suggested additional features for the app that are not in the invoice yet. Please use markdown format for the invoice. but dont add code block \'\'\'markdown"
      If the feature is not in the invoice, please ignore it.
      If the feature is deleted recently, tell the user that the feature is deleted recently.
      </RECAP>
      `;
        await send(request);
    }
    function hideLoading() {
        setPromptLoading(false);
        audioRef.current?.pause();
        if (audioRef.current) {
            audioRef.current.currentTime = 0;
        }
    }
    async function send(request) {
        const result = await chat.current.sendMessageStream(request);
        let modelRes = "";
        let firstChunkReceived = false; // Flag to track the first chunk
        for await (const chunk of result.stream){
            if (!firstChunkReceived) {
                // Stop loading and generating audio on the first chunk
                hideLoading();
                streamAudioRef.current?.play(); // Play typing audio
                firstChunkReceived = true;
            }
            const chunkText = chunk.text();
            modelRes += chunkText;
            // console.log(chunkText);
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addInvoiceChunk"])(chunkText));
        }
        // Stop typing audio after the stream finishes
        streamAudioRef.current?.pause();
        if (streamAudioRef.current) {
            streamAudioRef.current.currentTime = 0;
        }
        // Ensure loading and generating audio are stopped if the stream was empty or finished quickly
        if (!firstChunkReceived) {
            hideLoading();
        }
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["resetInvoiceChunk"])());
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addChatHistory"])({
            role: "model",
            text: modelRes
        }));
    }
    async function getFinalizeInvoice() {
        // To generate text output, call generateContent with the text input
        const finalizedInvoiceChat = model.current.startChat({
            history: await chat.current.getHistory()
        });
        const result = await finalizedInvoiceChat.sendMessage(`
      Finalized the invoice in table format. You should base your answer from the given <DATA>. If <DATA> has no information about the features, add the features to invoice and put (contact admin) in the price,duration,pages. Total the price, duration and pages that has valid data. Please use markdown format for the invoice. but dont add code block \'\'\'markdown".
      `);
        return result.response.text();
    }
    async function onPublish() {
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadingOn"])());
        const finalizedInvoice = await getFinalizeInvoice();
        // console.log("finalized::", finalizedInvoice);
        const publishInvoiceModel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGenerativeModel"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$vertexai$2f$dist$2f$esm$2f$index$2e$esm2017$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getVertexAI"])(), {
            model: newGeminiModel,
            systemInstruction: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$instruction$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SYSTEM_INSTRUCTION"],
            generationConfig: {
                responseMimeType: "application/json",
                responseSchema: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$config$2f$schema$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["INVOICE_SCHEMA"]
            }
        });
        const result = await publishInvoiceModel.generateContent(`
      ${finalizedInvoice}

      <RECAP>
      Please generate the invoice in JSON format. If the data is incomplete, please put (contact admin) in the price,duration,pages and for category you can put *Request*. Total the price, duration and pages that has valid data.
      <RECAP/>
      `);
        const res = result.response.text();
        console.log("res::", res);
        storeDispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$store$2f$invoice$2e$slice$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInvoice"])(JSON.parse(res)));
        /// set history for edit
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadingOff"])());
        router.push("/invoice");
    }
    async function onReset() {
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["reset"])());
        chat.current = model.current.startChat();
    }
    async function handleDeleteImage(file) {
        // console.log("handleDeleteImage", image);
        const res = confirm(`Delete uploaded image?`);
        if (!res) return;
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["removeFile"])(file));
    }
    function handleDropFiles(e) {
        e.preventDefault();
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDragging"])(false));
        console.log(e.dataTransfer.files);
        const files = Array.from(e.dataTransfer.files);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$firebase$2f$firebase$2e$functions$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["uploadFiles"])(files, {
            onUpload: (data)=>{
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addFile"])(data));
            },
            progress: (percent)=>{
                dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setProgress"])(percent));
            }
        });
    }
    function handleDragOver(e) {
        e.preventDefault();
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDragging"])(true));
    }
    function handleDragLeave(e) {
        e.preventDefault();
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setDragging"])(false));
    }
    function handlePlatformSelected(selectedPlatform) {
        console.log(selectedPlatform);
        setSelectedPlatform((platforms)=>({
                ...platforms,
                [selectedPlatform]: !platforms[selectedPlatform]
            }));
    }
    function onPlatformProceed() {
        if (!multiStepSelection.current.platformSelected) {
            multiStepSelection.current.platformSelected = true;
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addHistories"])([
                {
                    role: "model",
                    text: "Please select page"
                },
                {
                    role: "page-selection",
                    text: ""
                }
            ]));
        }
    }
    function handlePagesSelected(selectedPage) {
        if (!multiStepSelection.current.pageSelected) {
            multiStepSelection.current.pageSelected = true;
            dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addHistories"])([
                {
                    role: "model",
                    text: "Please select feature"
                },
                {
                    role: "feature-selection",
                    text: ""
                }
            ]));
        }
        setSelectedPages(selectedPage);
    }
    function handleFeatureSelected(selectedFeature) {
        setSelectedFeature(selectedFeature);
        if (!multiStepSelection.current.featureSelected) {
            multiStepSelection.current.featureSelected = true;
        }
        dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setInputBoxVisibility"])(true));
        generateAppDescription(selectedFeature);
    }
    async function generateAppDescription(feature) {
        const platforms = Object.entries(selectedPlatforms).filter(([, isSelected])=>isSelected) // Correctly filter selected platforms
        .map(([platform])=>platform) // Extract platform names
        .join(", ");
        const pages = selectedPages || 0;
        const prompt = t("prompt-app-description", {
            feature,
            pages,
            platforms
        });
        await submitPrompt(prompt);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "h-screen flex flex-col gap-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "flex justify-between items-center p-4 bg-gray-800 text-white",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: "/",
                            children: t("app-name")
                        }, void 0, false, {
                            fileName: "[project]/src/app/(chat)/page.tsx",
                            lineNumber: 455,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 454,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "button",
                                onClick: onReset,
                                children: t("reset")
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/page.tsx",
                                lineNumber: 458,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                className: "button",
                                onClick: onPublish,
                                children: state.loading ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$Spinner$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 462,
                                    columnNumber: 30
                                }, this) : t("publish")
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/page.tsx",
                                lineNumber: 461,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 457,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/page.tsx",
                lineNumber: 453,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                className: `p-5 relative ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$page$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].chatMessages}`,
                onDrop: (e)=>handleDropFiles(e),
                onDragOver: (e)=>handleDragOver(e),
                onDragLeave: (e)=>handleDragLeave(e),
                children: [
                    state.dragging && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute inset-0 flex items-center justify-center bg-blue-100 bg-opacity-75 z-10 h-full w-full",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-blue-500 font-bold text-lg",
                            children: "Add files or photos here"
                        }, void 0, false, {
                            fileName: "[project]/src/app/(chat)/page.tsx",
                            lineNumber: 474,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 473,
                        columnNumber: 11
                    }, this),
                    state.analysisLoading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$AnalysisChunck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 479,
                        columnNumber: 35
                    }, this),
                    (state.invoiceChunck || promptLoading) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$InvoiceChunck$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        invoiceChunck: state.invoiceChunck
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 481,
                        columnNumber: 11
                    }, this),
                    state.history.length > 0 && state.history.map((content, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, {
                            children: [
                                content.role === "user" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UserBubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    content: content
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 486,
                                    columnNumber: 43
                                }, this),
                                content.role === "model" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$InvoiceBubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    content: content,
                                    onDeleteFeature: onDeleteFeature
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 488,
                                    columnNumber: 17
                                }, this),
                                content.role === "file" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$ExtractAIBubble$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    content: content,
                                    onClick: ()=>{
                                        // console.log("onClick", content.hide);
                                        dispatch(content.hide ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["hideAnalysis"])(index) : (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["showAnalysis"])(index));
                                    }
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 494,
                                    columnNumber: 17
                                }, this),
                                content.role === "platform-selection" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$PlatformSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    selectedPlatforms: selectedPlatforms,
                                    handlePlatformSelected: handlePlatformSelected,
                                    onPlatformProceed: onPlatformProceed,
                                    disabled: multiStepSelection.current.platformSelected
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 506,
                                    columnNumber: 17
                                }, this),
                                content.role === "page-selection" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$PageSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    selectedPages: selectedPages,
                                    handlePagesSelected: handlePagesSelected,
                                    disabled: multiStepSelection.current.pageSelected
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 514,
                                    columnNumber: 17
                                }, this),
                                content.role === "feature-selection" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$_components$2f$FeatureSelection$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    selectedFeature: selectedFeature,
                                    handleFeatureSelected: handleFeatureSelected,
                                    disabled: multiStepSelection.current.featureSelected
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 521,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, index, true, {
                            fileName: "[project]/src/app/(chat)/page.tsx",
                            lineNumber: 485,
                            columnNumber: 13
                        }, this))
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/page.tsx",
                lineNumber: 466,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$withcenter$2d$react$2d$library$2f$components$2f$Loading$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                loading: promptLoading
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/page.tsx",
                lineNumber: 530,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UploadedChatFiles$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                files: state.files,
                onDelete: handleDeleteImage
            }, void 0, false, {
                fileName: "[project]/src/app/(chat)/page.tsx",
                lineNumber: 531,
                columnNumber: 7
            }, this),
            state.isInputBoxVisible && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
                className: "px-5 pt-3 pb-15",
                children: [
                    state.progress > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full bg-gray-200 rounded-full h-1.5 mb-4 dark:bg-gray-700",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "bg-blue-600 h-1.5 rounded-full dark:bg-blue-500",
                            style: {
                                width: (state.progress > 20 ? state.progress : 20) + "%"
                            }
                        }, void 0, false, {
                            fileName: "[project]/src/app/(chat)/page.tsx",
                            lineNumber: 536,
                            columnNumber: 15
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 535,
                        columnNumber: 13
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        className: "flex gap-3",
                        onSubmit: onSubmit,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$UploadImageButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onUpload: async (data)=>dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["addFile"])(data)),
                                progress: (percent)=>{
                                    // console.log("progress", percent);
                                    dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setProgress"])(percent));
                                }
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/page.tsx",
                                lineNumber: 545,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                name: "message",
                                className: "border border-slate-400 p-2 rounded-md w-full",
                                type: "text",
                                placeholder: t("type-your-message-here"),
                                onChange: (e)=>dispatch((0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$chat$2e$reducer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["setPrompt"])(e.target.value)),
                                value: state.prompt
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/page.tsx",
                                lineNumber: 552,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "submit",
                                className: "px-3",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    xmlns: "http://www.w3.org/2000/svg",
                                    fill: "none",
                                    viewBox: "0 0 24 24",
                                    strokeWidth: 1.5,
                                    stroke: "currentColor",
                                    className: "size-8 mx-2",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        d: "M6 12 3.269 3.125A59.769 59.769 0 0 1 21.485 12 59.768 59.768 0 0 1 3.27 20.875L5.999 12Zm0 0h7.5"
                                    }, void 0, false, {
                                        fileName: "[project]/src/app/(chat)/page.tsx",
                                        lineNumber: 570,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/src/app/(chat)/page.tsx",
                                    lineNumber: 562,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/app/(chat)/page.tsx",
                                lineNumber: 561,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/app/(chat)/page.tsx",
                        lineNumber: 544,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/src/app/(chat)/page.tsx",
                lineNumber: 533,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/app/(chat)/page.tsx",
        lineNumber: 452,
        columnNumber: 5
    }, this);
}
_s(ChatPage, "biDDVjsXMPI9KjMrvqZo2QIkdxc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$redux$2f$dist$2f$react$2d$redux$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDispatch"],
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$app$2f28$chat$292f$hooks$2f$useAI$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$intl$2f$dist$2f$esm$2f$development$2f$react$2d$client$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTranslations"]
    ];
});
_c = ChatPage;
var _c;
__turbopack_context__.k.register(_c, "ChatPage");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_2ed33d97._.js.map