import { SYSTEM_INSTRUCTION } from "@/config/instruction";
import { collection, getDocs, getFirestore, query } from "firebase/firestore";
import {
  ChatSession,
  GenerativeModel,
  getGenerativeModel,
  getVertexAI,
} from "firebase/vertexai";
import { useEffect, useRef } from "react";

export default function useAI() {
  const GEMINI_MODEL = "gemini-2.5-pro-preview-03-25";

  const model = useRef({} as GenerativeModel);
  const chat = useRef({} as ChatSession);
  const initialized = useRef(false);

  useEffect(() => {
    if (!initialized.current) {
      (async () => {
        const q = query(collection(getFirestore(), "features"));
        const querySnapshot = await getDocs(q);

        let featuresData = "";
        querySnapshot.forEach((doc) => {
          console.log(doc.id, " => ", doc.data());
          featuresData += `${JSON.stringify(doc.data())}`;
        });

        const updatedSystemInstruction = `${SYSTEM_INSTRUCTION}  <DATA> ${featuresData} </DATA>`;
        console.log("updatedSystemInstruction", updatedSystemInstruction);

        model.current = getGenerativeModel(getVertexAI(), {
          model: GEMINI_MODEL,
          systemInstruction: updatedSystemInstruction,
        });
        chat.current = model.current.startChat();
      })();
      initialized.current = true;
    }
  }, []);

  return { model, chat };
}
