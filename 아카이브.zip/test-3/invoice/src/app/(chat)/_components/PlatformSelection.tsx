import { useTranslations } from "next-intl";

interface PlatformSelectionProps {
  selectedPlatforms: { [key: string]: boolean };
  handlePlatformSelected: (
    platform: "web" | "mobile" | "ios" | "android" | "windows"
  ) => void;
  onPlatformProceed: () => void;
  disabled: boolean;
}

export default function PlatformSelection({
  selectedPlatforms,
  handlePlatformSelected,
  onPlatformProceed,
  disabled,
}: PlatformSelectionProps) {
  const t = useTranslations();
  return (
    <fieldset className="flex items-center justify-around w-full">
      <legend>{t("platform-selection")}</legend>
      <div className="flex flex-col gap-4 items-center">
        Web:
        <div className="flex gap-4">
          <button
            className={`${
              selectedPlatforms.web ? "bg-blue-800 text-white" : ""
            } ${disabled ? "cursor-not-allowed " : ""}`}
            onClick={() => handlePlatformSelected("web")}
            disabled={disabled}
          >
            Web
          </button>
          <button
            className={`${
              selectedPlatforms.mobile ? "bg-blue-800 text-white" : ""
            } ${disabled ? "cursor-not-allowed " : ""}`}
            onClick={() => handlePlatformSelected("mobile")}
            disabled={disabled}
          >
            Mobile
          </button>
        </div>
      </div>
      <div className="flex flex-col gap-4 items-center">
        App:
        <div className="flex gap-4">
          <button
            className={`${
              selectedPlatforms.ios ? "bg-blue-800 text-white" : ""
            } ${disabled ? "cursor-not-allowed " : ""}`}
            onClick={() => handlePlatformSelected("ios")}
            disabled={disabled}
          >
            iOS
          </button>
          <button
            className={`${
              selectedPlatforms.android ? "bg-blue-800 text-white" : ""
            } ${disabled ? "cursor-not-allowed " : ""}`}
            onClick={() => handlePlatformSelected("android")}
            disabled={disabled}
          >
            Android
          </button>
        </div>
      </div>
      <button
        className={`${
          selectedPlatforms.windows ? "bg-blue-800 text-white" : ""
        } ${disabled ? "cursor-not-allowed " : ""}`}
        onClick={() => handlePlatformSelected("windows")}
        disabled={disabled}
      >
        Windows
      </button>
      <button
        className={`mt-4 px-4 py-2 bg-green-600 text-white rounded ${
          disabled ? "cursor-not-allowed " : ""
        }`}
        onClick={onPlatformProceed}
        disabled={disabled}
      >
        Proceed
      </button>
    </fieldset>
  );
}
