import Markdown from "react-markdown";
import Spinner from "../../../components/Spinner";
import { useTranslations } from "next-intl";
import remarkGfm from "remark-gfm";

export default function InvoiceChunck({
  invoiceChunck,
}: {
  invoiceChunck: string;
}) {
  const t = useTranslations();

  return (
    <article className={`flex flex-col`}>
      <h3 className={`flex text-sm text-gray-500 `}>{t("app-name")}</h3>
      <section className="flex">
        <data className="bg-green-100 w-11/12 p-4 rounded-md mb-4">
          <Markdown remarkPlugins={[remarkGfm]}>{invoiceChunck}</Markdown>
          <Spinner />
        </data>
      </section>
    </article>
  );
}
