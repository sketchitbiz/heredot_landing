import { useTranslations } from "next-intl";

interface PageSelectionProps {
  selectedPages: number;
  handlePagesSelected: (pages: number) => void;
  disabled: boolean;
}

export default function PageSelection({
  selectedPages,
  handlePagesSelected,
  disabled,
}: PageSelectionProps) {
  const t = useTranslations();
  return (
    <fieldset className="flex flex-col items-center gap-4">
      <legend>{t("choose-pages")}</legend>
      <div className="flex gap-4">
        <button
          className={`${selectedPages === 5 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(5)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 5 })}
        </button>
        <button
          className={`${selectedPages === 10 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(10)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 10 })}
        </button>
        <button
          className={`${selectedPages === 20 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(20)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 20 })}
        </button>
      </div>

      <div className="flex gap-4">
        <button
          className={`${selectedPages === 30 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(30)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 30 })}
        </button>
        <button
          className={`${selectedPages === 40 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(40)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 40 })}
        </button>
        <button
          className={`${selectedPages === 50 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(50)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 50 })}
        </button>
      </div>
      <div className="flex gap-4">
        <button
          className={`${selectedPages === 70 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(70)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 70 })}
        </button>
        <button
          className={`${selectedPages === 90 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(90)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 90 })}
        </button>
        <button
          className={`${selectedPages === 100 ? "bg-blue-800 " : ""} ${
            disabled ? "cursor-not-allowed " : ""
          }`}
          onClick={() => handlePagesSelected(100)}
          disabled={disabled}
        >
          {t("less-than-pages", { number: 100 })}
        </button>
      </div>
    </fieldset>
  );
}
