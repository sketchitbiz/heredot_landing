import { useTranslations } from "next-intl";

interface FeatureSelectionProps {
  selectedFeature: string;
  handleFeatureSelected: (feature: string) => void;
  disabled: boolean;
}

export default function FeatureSelection({
  selectedFeature,
  handleFeatureSelected,
  disabled,
}: FeatureSelectionProps) {
  const t = useTranslations();
  return (
    <fieldset className="flex flex-col items-center gap-4">
      <legend>{t("choose-feature")}</legend>
      <div className="flex gap-4 flex-wrap">
        <button
          className={`${
            selectedFeature === "Travel/Transportation" ? "bg-blue-800" : ""
          } ${disabled ? "cursor-not-allowed" : ""}`}
          onClick={() => handleFeatureSelected("Travel/Transportation")}
          disabled={disabled}
        >
          {t("travel-transportation")}
        </button>
        <button
          className={`${selectedFeature === "IoT App" ? "bg-blue-800" : ""} ${
            disabled ? "cursor-not-allowed" : ""
          }`}
          onClick={() => handleFeatureSelected("IoT App")}
          disabled={disabled}
        >
          {t("iot-app")}
        </button>
        <button
          className={`${
            selectedFeature === "Health/Medical" ? "bg-blue-800" : ""
          } ${disabled ? "cursor-not-allowed" : ""}`}
          onClick={() => handleFeatureSelected("Health/Medical")}
          disabled={disabled}
        >
          {t("health-medical")}
        </button>
        <button
          className={`${
            selectedFeature === "Finance/Fund" ? "bg-blue-800" : ""
          } ${disabled ? "cursor-not-allowed" : ""}`}
          onClick={() => handleFeatureSelected("Finance/Fund")}
          disabled={disabled}
        >
          {t("finance-fund")}
        </button>
        <button
          className={`${selectedFeature === "Food" ? "bg-blue-800" : ""} ${
            disabled ? "cursor-not-allowed" : ""
          }`}
          onClick={() => handleFeatureSelected("Food")}
          disabled={disabled}
        >
          {t("food")}
        </button>
        <button
          className={`${selectedFeature === "Community" ? "bg-blue-800" : ""} ${
            disabled ? "cursor-not-allowed" : ""
          }`}
          onClick={() => handleFeatureSelected("Community")}
          disabled={disabled}
        >
          {t("community")}
        </button>
        <button
          className={`${selectedFeature === "Shopping" ? "bg-blue-800" : ""} ${
            disabled ? "cursor-not-allowed" : ""
          }`}
          onClick={() => handleFeatureSelected("Shopping")}
          disabled={disabled}
        >
          {t("shopping")}
        </button>
        <button
          className={`${
            selectedFeature === "Reverse Auction" ? "bg-blue-800" : ""
          } ${disabled ? "cursor-not-allowed" : ""}`}
          onClick={() => handleFeatureSelected("Reverse Auction")}
          disabled={disabled}
        >
          {t("reverse-auction")}
        </button>
        <button
          className={`${selectedFeature === "Use Trade" ? "bg-blue-800" : ""} ${
            disabled ? "cursor-not-allowed" : ""
          }`}
          onClick={() => handleFeatureSelected("Use Trade")}
          disabled={disabled}
        >
          {t("use-trade")}
        </button>
        <button
          className={`${selectedFeature === "O2O" ? "bg-blue-800" : ""} ${
            disabled ? "cursor-not-allowed" : ""
          }`}
          onClick={() => handleFeatureSelected("O2O")}
          disabled={disabled}
        >
          {t("o2o")}
        </button>
        <button
          className={`${
            selectedFeature === "Pay Platform" ? "bg-blue-800" : ""
          } ${disabled ? "cursor-not-allowed" : ""}`}
          onClick={() => handleFeatureSelected("Pay Platform")}
          disabled={disabled}
        >
          {t("pay-platform")}
        </button>
      </div>
    </fieldset>
  );
}
