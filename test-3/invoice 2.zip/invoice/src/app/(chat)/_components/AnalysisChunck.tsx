import Spinner from "@/components/Spinner";
import { useTranslations } from "next-intl";

export default function AnalysisChunck() {
  const t = useTranslations();

  return (
    <article className={`flex flex-col items-end`}>
      <h3 className={`flex text-sm text-gray-500`}>{t("analysis-name")}</h3>
      <section className="flex">
        <data className="bg-yellow-100 w-11/12 p-4 rounded-md mb-4 flex items-center">
          {/* <Markdown remarkPlugins={[remarkGfm]}>
                  {state.analyzeChunck}
                </Markdown> */}
          <Spinner />
        </data>
      </section>
    </article>
  );
}
