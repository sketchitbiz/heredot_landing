// eslint-disable-next-line
export type RecordType = Record<string, any>;