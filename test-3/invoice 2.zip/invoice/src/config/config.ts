export class Config {}
